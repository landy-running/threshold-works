
# はじめての公開（超かんたん版）

## A. 準備（1回だけ）
- Node.js (LTS)
- GitHub Desktop
- Cloudflare アカウント

## B. ローカルで表示
```
npm i
npm run dev
```

## C. 記事の作成
```
npm run new
```

## D. 公開（Cloudflare Pages）
- Connect to Git → Astro → `npm run build` / `dist`

## E. 予約投稿
- GitHub Secrets を設定 → 毎日 03:00 JST に再ビルド

## F. 初期設定
```
npm run setup
```
