
# Threshold Works (Astro)

- 検索、RSS、OG自動生成、画像最適化、タグページ、Issue→投稿自動化（iPhone向け）入り。

## よく使う
- 表示: `npm run dev`
- 新規: `npm run new`
- 検索: `/search`
- タグ: `/tags`
- RSS: `/rss.xml`
