
# iPhoneだけで投稿・公開する方法

## 1) リポジトリを作る → ZIPをアップ
- GitHubアプリ → New repository → 作成
- Safariでリポジトリ → **Upload files** → ZIPを選択 → Commit

## 2) （任意）CodespacesでZIPを展開
```
unzip threshold-works-starter.zip -d .
shopt -s dotglob
mv threshold-works/* .
rmdir threshold-works || true
rm threshold-works-starter.zip
git add -A && git commit -m "import starter" && git push
```

## 3) Cloudflare Pagesに接続（Astro / `npm run build` / `dist`）

## 4) 投稿（最短：Quick Post）
- GitHubアプリ → Issues → **New issue** → **Quick Post**
- 本文に画像を**貼り付け**OK（自動で `/uploads/` に保存＆差し替え）
- `#タグ` を本文に書けばタグとして自動抽出

- 送信後：PR自動作成 → **automerge** ラベルにより即マージ → Cloudflareが自動公開

## 5) 直接コミット（上級）
- Issueに `direct-commit` ラベルを付けて作成 → PRなしで main に直コミット（保護ルールがあると失敗）

トラブル時は Actions → 実行ログを確認してください。
