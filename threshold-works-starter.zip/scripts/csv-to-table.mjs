
import fs from 'node:fs';
const [,, file] = process.argv;
if(!file) { console.error('Usage: node scripts/csv-to-table.mjs <file.csv>'); process.exit(1); }
const txt = fs.readFileSync(file, 'utf8').trim();
const rows = txt.split(/\r?\n/).map(l => l.split(','));
const header = rows[0];
const body = rows.slice(1);
const sep = '|' + header.map(()=> '---').join('|') + '|';
console.log('|' + header.join('|') + '|');
console.log(sep);
for(const r of body){ console.log('|' + r.join('|') + '|'); }
