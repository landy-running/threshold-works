
import fs from 'node:fs';
import path from 'node:path';
import matter from 'gray-matter';
import { Resvg } from '@resvg/resvg-js';

const contentRoot = 'src/content';
const outDir = 'public/og';
fs.mkdirSync(outDir, { recursive: true });

const collections = fs.readdirSync(contentRoot).filter(d => fs.statSync(path.join(contentRoot,d)).isDirectory());

function wrapText(t, max = 18){
  const words = t.split(/(\s+)/);
  const lines = [];
  let line = '';
  for (const w of words){
    if ((line + w).length > max) { lines.push(line.trim()); line = w; }
    else { line += w; }
  }
  if (line.trim()) lines.push(line.trim());
  return lines.slice(0,6);
}

for (const c of collections){
  const dir = path.join(contentRoot, c);
  for (const file of fs.readdirSync(dir)){
    if (!file.endsWith('.md') && !file.endsWith('.mdx')) continue;
    const slug = file.replace(/\.(md|mdx)$/, '');
    const raw = fs.readFileSync(path.join(dir, file),'utf8');
    const fm = matter(raw).data || {};
    const title = (fm.title || slug).toString();
    const lines = wrapText(title, 18);

    const svg = `
    <svg width="1200" height="630" viewBox="0 0 1200 630" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#0b0c10"/>
          <stop offset="1" stop-color="#111218"/>
        </linearGradient>
      </defs>
      <rect width="1200" height="630" fill="url(#g)"/>
      <rect x="40" y="40" width="1120" height="550" rx="24" fill="#0d0e14" stroke="#1a1b23"/>
      <text x="80" y="130" font-size="22" fill="#90a4ff" font-family="Inter, Arial, sans-serif">Threshold Works</text>
      ${lines.map((ln, i)=>`<text x="80" y="${220 + i*64}" font-size="56" fill="#e6e7ea" font-family="Inter, Arial, sans-serif">${ln.replace(/&/g,'&amp;')}</text>`).join('')}
      <text x="80" y="540" font-size="24" fill="#a9adbb" font-family="Inter, Arial, sans-serif">${c.toUpperCase()}</text>
    </svg>`;

    const pngPath = path.join(outDir, `${c}-${slug}.png`);
    const resvg = new Resvg(svg, { fitTo: { mode: 'width', value: 1200 } });
    const png = resvg.render().asPng();
    fs.writeFileSync(pngPath, png);
  }
}
console.log('OG images generated:', outDir);
