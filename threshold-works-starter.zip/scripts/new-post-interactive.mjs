
import fs from 'node:fs';
import readline from 'node:readline';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(res => rl.question(q, ans => res(ans.trim())));

const map = { '1':'reviews','2':'tips','3':'races','4':'training','5':'labs' };
const tmap = { reviews:'review.md', tips:'tips.md', races:'race.md', training:'training.md', labs:'labs.md' };

(async () => {
  console.log('Collection: 1)レビュー 2)ノウハウ 3)レース 4)トレーニング 5)Labs');
  const c = map[await ask('番号を選択: ')];
  const title = await ask('タイトル: ');
  let date = await ask('日付(YYYY-MM-DD, 空で今日): ');
  if(!date){ date = new Date().toISOString().slice(0,10); }
  const draft = (await ask('下書きにしますか？(y/N): ')).toLowerCase().startsWith('y');
  const slug = title.toLowerCase().replace(/[^a-z0-9\s-]/g,'').trim().replace(/\s+/g,'-').slice(0,60) || 'post';

  const tplPath = `templates/${tmap[c]}`;
  if(!fs.existsSync(tplPath)) { console.error('テンプレートが見つかりません:', tplPath); process.exit(2); }
  let md = fs.readFileSync(tplPath, 'utf8').replace(/__TITLE__/g, title).replace(/__DATE__/g, date);
  if(draft) md = md.replace('---\n', '---\ndraft: true\n');

  const outDir = `src/content/${c}`;
  fs.mkdirSync(outDir, { recursive: true });
  const out = `${outDir}/${slug}.md`;
  fs.writeFileSync(out, md, 'utf8');
  console.log('Created:', out);
  rl.close();
})();
