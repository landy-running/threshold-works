
import fs from 'node:fs';
import path from 'node:path';

const [,, collection, title, dateArg, slugArg] = process.argv;
if (!collection || !title) {
  console.error('Usage: node scripts/new-post.mjs <collection> "<title>" [YYYY-MM-DD] ["slug"]');
  process.exit(1);
}
const date = dateArg || new Date().toISOString().slice(0,10);
const slug = (slugArg || title.toLowerCase().replace(/[^a-z0-9\s-]/g,'').trim().replace(/\s+/g,'-').slice(0,60)) || 'post';

const templatesDir = path.join('templates');
const templateMap = { reviews: 'review.md', tips: 'tips.md', races: 'race.md', training: 'training.md', labs: 'labs.md' };
const tplPath = path.join(templatesDir, templateMap[collection] || 'tips.md');
if (!fs.existsSync(tplPath)) { console.error(`Template not found for ${collection}`); process.exit(2); }
const contentDir = path.join('src','content', collection);
fs.mkdirSync(contentDir, { recursive: true });

let md = fs.readFileSync(tplPath, 'utf8');
md = md.replace(/__TITLE__/g, title).replace(/__DATE__/g, date);
const outfile = path.join(contentDir, `${slug}.md`);
fs.writeFileSync(outfile, md, 'utf8');
console.log('Created:', outfile);
