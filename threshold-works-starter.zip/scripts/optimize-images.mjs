
import fs from 'node:fs';
import path from 'node:path';
import { ImagePool } from '@squoosh/lib';

const dist = 'dist';
const pool = new ImagePool(1);

function* walk(dir){
  for (const e of fs.readdirSync(dir, { withFileTypes: true })){
    const p = path.join(dir, e.name);
    if (e.isDirectory()) yield* walk(p);
    else yield p;
  }
}

const targets = [];
for (const p of walk(dist)){
  if (p.match(/\.(png|jpe?g)$/i)) targets.push(p);
}
for (const imgPath of targets){
  const img = pool.ingestImage(fs.readFileSync(imgPath));
  await img.encode({ webp: { quality: 80 }});
  const { binary } = (await img.encodedWith.webp);
  const out = imgPath.replace(/\.(png|jpe?g)$/i, '.webp');
  fs.writeFileSync(out, binary);
}
await pool.close();

for (const p of walk(dist)){
  if (!p.endsWith('.html')) continue;
  let html = fs.readFileSync(p, 'utf8');
  html = html.replace(/<img([^>]*?)src="([^"]+\.(?:png|jpe?g))"([^>]*)>/gi, (m, pre, src, post) => {
    const webp = src.replace(/\.(png|jpe?g)$/i, '.webp');
    return `<picture><source srcset="${webp}" type="image/webp"><img${pre}src="${src}"${post}></picture>`;
  });
  fs.writeFileSync(p, html, 'utf8');
}
console.log('Images optimized & HTML patched.');
