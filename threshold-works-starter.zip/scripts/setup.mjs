
import fs from 'node:fs';
import readline from 'node:readline';
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(res => rl.question(q, ans => res(ans.trim())));
(async () => {
  let siteCfg = fs.readFileSync('src/site.config.ts', 'utf8');
  let astroCfg = fs.readFileSync('astro.config.mjs', 'utf8');
  const name = await ask('サイト名 (Enterで現状維持): ');
  const tagline = await ask('タグライン (Enterで現状維持): ');
  const desc = await ask('説明 (Enterで現状維持): ');
  const siteUrl = await ask('サイトURL (例 https://your.pages.dev, Enterで現状維持): ');
  if (name) siteCfg = siteCfg.replace(/siteName:\s*".*?"/, `siteName: "${name}"`);
  if (tagline) siteCfg = siteCfg.replace(/tagline:\s*".*?"/, `tagline: "${tagline}"`);
  if (desc) siteCfg = siteCfg.replace(/description:\s*".*?"/, `description: "${desc}"`);
  if (siteUrl) astroCfg = astroCfg.replace(/site:\s*'.*?'/, `site: '${siteUrl}'`);
  fs.writeFileSync('src/site.config.ts', siteCfg, 'utf8');
  fs.writeFileSync('astro.config.mjs', astroCfg, 'utf8');
  console.log('設定を更新しました。'); rl.close();
})();
