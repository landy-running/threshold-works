
import fs from 'node:fs';
import path from 'node:path';
const root = 'src/content';
const collections = fs.readdirSync(root).filter(d => fs.statSync(path.join(root,d)).isDirectory());
let ok = true;
for (const c of collections){
  const dir = path.join(root, c);
  for (const f of fs.readdirSync(dir)){
    if (!/\.(md|mdx)$/.test(f)) continue;
    const p = path.join(dir, f);
    const txt = fs.readFileSync(p, 'utf8');
    const m = /^---\n([\s\S]*?)\n---/m.exec(txt);
    if (!m){ console.error('⚠️ frontmatter missing:', p); ok = false; continue; }
    const fm = Object.fromEntries(Array.from(m[1].matchAll(/^(\w+):\s*(.*)$/mg)).map(x => [x[1], x[2]]));
    for (const key of ['title','description','pubDate']){
      if (!(key in fm)){ console.error(`⚠️ missing ${key}:`, p); ok = false; }
    }
  }
}
if (!ok) process.exit(2);
console.log('✅ content ok');
