import { defineCollection, z } from 'astro:content';

const base = {
  schema: z.object({
    title: z.string(),
    description: z.string(),
    pubDate: z.string(),
    heroImage: z.string().optional(),
    tags: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  })
};

export const collections = {
  reviews: defineCollection(base),
  tips: defineCollection(base),
  races: defineCollection(base),
  training: defineCollection(base),
  labs: defineCollection(base),
};