---
title: "サンプルレビュー：厚底×安定の検証"
description: "心拍・接地・上下動で評価。平日ロングの最有力を検証。"
pubDate: "2025-08-13"
tags: ["レビュー", "シューズ"]
---
import ReviewMetrics from "../../components/ReviewMetrics.astro";

## 実測まとめ
<ReviewMetrics pace="4:35/km" hr="144" pitch="176" vo="9.4" gct="280" shoes="サンプルモデル" note="気温30℃・トレミ1%勾配" />

## 所感
- サンプルなので編集してください。
