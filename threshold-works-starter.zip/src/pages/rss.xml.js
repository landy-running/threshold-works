import rss from '@astrojs/rss';
import site from '../../src/site.config.ts';
import { getCollection } from 'astro:content';

export async function GET(context) {
  const visible = [
    ...(await getCollection('reviews')),
    ...(await getCollection('tips')),
    ...(await getCollection('races')),
    ...(await getCollection('training')),
    ...(await getCollection('labs')),
  ].filter(p => !p.data.draft && (import.meta.env.DEV || new Date(p.data.pubDate) <= new Date()))
   .sort((a,b) => new Date(b.data.pubDate) - new Date(a.data.pubDate));

  return rss({
    title: site.siteName,
    description: site.description,
    site: context.site || 'https://example.com',
    items: visible.map((p) => ({
      title: p.data.title,
      pubDate: new Date(p.data.pubDate),
      description: p.data.description,
      link: '/' + (p.collection.replace('reviews','review').replace('races','race')) + '/' + p.slug + '/',
    })),
  });
}