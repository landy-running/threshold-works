const site = {
  siteName: "Threshold Works",
  tagline: "データで速くなるランニング",
  description: "心拍・接地・上下動などの実測で、トレーニングとギアを評価する。",
  author: "あなたの名前",
};
export default site;