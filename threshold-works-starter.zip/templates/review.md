---
title: "__TITLE__"
description: "要約（120字目安）。用途・強み・誰に刺さるか。"
pubDate: "__DATE__"
tags: ["レビュー"]
---
## 概要
- テスト条件：距離/コース/天候/勾配/ウェア

## 実測まとめ（ショートコード例）
import ReviewMetrics from "../../components/ReviewMetrics.astro";
<ReviewMetrics pace="4:35/km" hr="144" pitch="176" vo="9.4" gct="280" shoes="モデル名" note="気温/条件など" />

## 良かった点
- 

## 気になった点
- 

## 競合比較
- 

## 結論
- こういう人に最適：
- 使用推奨シーン：
